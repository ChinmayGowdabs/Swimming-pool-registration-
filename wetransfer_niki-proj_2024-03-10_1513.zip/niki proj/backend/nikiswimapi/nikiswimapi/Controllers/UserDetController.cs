﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using nikiswimapi.Models;
using nikiswimapi.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace nikiswimapi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserDetController : ControllerBase
    {
        UserDetailsServices _casteservices;
        public UserDetController(UserDetailsServices casteservices)
        {
            _casteservices = casteservices;
        }

        [HttpPost("AddUserDets")]
        public IActionResult AddUserDets([FromBody] userdetails HobliVm)
        {
            try
            {
                _casteservices.AddUserDets(HobliVm);
                return Ok();
            }
            catch (Exception)
            {

                return StatusCode(StatusCodes.Status500InternalServerError, "Error in Adding Hobliname");
            }
        }

        [HttpGet("getUserDetsList")]
        public IActionResult getUserDetsList()
        {
            try
            {
                var getlist = _casteservices.getUserDetsList();
                return Ok(getlist);
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Error in getting dep");
            }
        }


        [HttpGet("getdetailsbyuserid")]
        public IActionResult GetDetailsByUserId(int id)  // Corrected method name and added parameter
        {
            try
            {
                var getlist = _casteservices.getdetailsbyuserid(id);  // Corrected method call
                return Ok(getlist);
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Error in getting details");
            }
        }
    }
}
