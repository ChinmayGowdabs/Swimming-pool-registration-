﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using nikiswimapi.Models;
using nikiswimapi.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace nikiswimapi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserCredController : ControllerBase
    {
        UserCredentialServices _casteservices;
        public UserCredController(UserCredentialServices casteservices)
        {
            _casteservices = casteservices;
        }

        [HttpPost("AddCredDets")]
        public IActionResult AddCredDets([FromBody] UserCredentials HobliVm)
        {
            try
            {
                _casteservices.AddCredDets(HobliVm);
                return Ok();
            }
            catch (Exception)
            {

                return StatusCode(StatusCodes.Status500InternalServerError, "Error in Adding Hobliname");
            }
        }

        [HttpGet("getCredList")]
        public IActionResult getCredList()
        {
            try
            {
                var getlist = _casteservices.getCredList();
                return Ok(getlist);
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Error in getting dep");
            }
        }
        [HttpPost("authenticate")]
        public IActionResult Authenticate([FromBody] UserCredentials userCredentials)
        {
            // Assuming you have a DTO (Data Transfer Object) for user credentials
            // Make sure to validate and sanitize input before processing

            var (isAuthenticated, userId) = _casteservices.AuthenticateUser(userCredentials.Email, userCredentials.Password);

            if (isAuthenticated)
            {
                return Ok(new { Message = "Authentication successful", UserId = userId });
            }
            else
            {
                return Unauthorized(new { Message = "Authentication failed" });
            }
        }
    }
}
