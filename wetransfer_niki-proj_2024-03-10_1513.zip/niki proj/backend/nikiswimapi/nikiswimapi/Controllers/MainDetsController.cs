﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using nikiswimapi.Models;
using nikiswimapi.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace nikiswimapi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MainDetsController : ControllerBase
    {
        maindetailsservices _casteservices;
        public MainDetsController(maindetailsservices casteservices)
        {
            _casteservices = casteservices;
        }

        [HttpPost("AddMainDets")]
        public IActionResult AddMainDets([FromBody] maindetails HobliVm)
        {
            try
            {
                _casteservices.AddMainDets(HobliVm);
                return Ok();
            }
            catch (Exception)
            {

                return StatusCode(StatusCodes.Status500InternalServerError, "Error in Adding Hobliname");
            }
        }

        [HttpGet("getMaindetList")]
        public IActionResult getMaindetList()
        {
            try
            {
                var getlist = _casteservices.getMaindetList();
                return Ok(getlist);
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Error in getting dep");
            }
        }

    }
}
