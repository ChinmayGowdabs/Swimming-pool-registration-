﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace nikiswimapi.viewmodels
{
    public class viewdetailsvm
    {

        public string username { get; set; }
        public string batch { get; set; }
        public string mail { get; set; }

        public string gender { get; set; }
        public long phoneno { get; set; }
        public DateTime dob { get; set; }
        public string sonof { get; set; }
        public long fatherphoneno { get; set; }

        public float Height { get; set; }
        public float Weight { get; set; }

    }
}
