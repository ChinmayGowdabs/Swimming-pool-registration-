﻿using nikiswimapi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace nikiswimapi.Services
{
    public class maindetailsservices
    {
        public ApplicationDbContext _applicationDbContext;
        public maindetailsservices(ApplicationDbContext applicationDbContext)
        {
            _applicationDbContext = applicationDbContext;
        }

        public void AddMainDets(maindetails _userdetails)
        {
            var add = new maindetails()
            {
                username = _userdetails.username,
                email = _userdetails.email,
                phonenum = _userdetails.phonenum,
                fathername = _userdetails.fathername,
                fathernum = _userdetails.fathernum,
                ht = _userdetails.ht,
                wt = _userdetails.wt,
                dob = _userdetails.dob,
                gender = _userdetails.gender,
                batch = _userdetails.batch
            };
            _applicationDbContext.Add(add);
            _applicationDbContext.SaveChanges();
        }

        public List<maindetails> getMaindetList()
        {
            var get = _applicationDbContext.maindetails.ToList();
            return get;
        }
    }
}
