﻿using nikiswimapi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace nikiswimapi.Services
{
    public class UserCredentialServices
    {
        public ApplicationDbContext _applicationDbContext;
        public UserCredentialServices(ApplicationDbContext applicationDbContext)
        {
            _applicationDbContext = applicationDbContext;
        }

        public void AddCredDets(UserCredentials _userdetails)
        {
            var add = new UserCredentials()
            {
                UserName = _userdetails.UserName,
                Email = _userdetails.Email,
                Password = _userdetails.Password,

            };
            _applicationDbContext.Add(add);
            _applicationDbContext.SaveChanges();
        }

        public List<UserCredentials> getCredList()
        {
            var get = _applicationDbContext.UserCredentials.ToList();
            return get;
        }
        public (bool isAuthenticated, int userId) AuthenticateUser(string email, string password)
        {
            // Check if there is a user with the provided email and password
            var user = _applicationDbContext.UserCredentials
                .FirstOrDefault(u => u.Email == email && u.Password == password);

            // If a user is found, authentication is successful
            if (user != null)
            {
                return (true, user.Userid); // Authentication success with user ID
            }

            return (false, 0); // Authentication failure
        }
    }
}
