﻿using nikiswimapi.Models;
using nikiswimapi.viewmodels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace nikiswimapi.Services
{
    public class UserDetailsServices
    {
        public ApplicationDbContext _applicationDbContext;
        public UserDetailsServices(ApplicationDbContext applicationDbContext)
        {
            _applicationDbContext = applicationDbContext;
        }

        public void AddUserDets(userdetails _userdetails)
        {
            var add = new userdetails()
            {
                Userid = _userdetails.Userid,
                batch = _userdetails.batch,
                gender = _userdetails.gender,
                phoneno = _userdetails.phoneno,
                dob = _userdetails.dob,
                sonof = _userdetails.sonof,
                fatherphoneno = _userdetails.fatherphoneno,
                Height = _userdetails.Height,
                Weight = _userdetails.Weight
            };
            _applicationDbContext.Add(add);
            _applicationDbContext.SaveChanges();
        }

        public List<userdetails> getUserDetsList()
        {
            var get = _applicationDbContext.userdetails.ToList();
            return get;
        }
        public viewdetailsvm getdetailsbyuserid(int id)
        {
            var nominee = _applicationDbContext.userdetails
                .Where(n => n.Userid == id)
                .Select(hobli => new viewdetailsvm
                {
                    username = hobli.UserCredentials.UserName,
                    mail = hobli.UserCredentials.Email,
                    batch = hobli.batch,
                    gender = hobli.gender,
                    phoneno = hobli.phoneno,
                    dob = hobli.dob,
                    sonof = hobli.sonof,
                    fatherphoneno = hobli.fatherphoneno,
                    Height = hobli.Height,
                    Weight = hobli.Weight,
                })
                .FirstOrDefault();
            return nominee;
        }
    }
}
