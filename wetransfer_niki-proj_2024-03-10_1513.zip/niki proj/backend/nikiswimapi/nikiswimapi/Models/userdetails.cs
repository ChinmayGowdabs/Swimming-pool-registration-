﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace nikiswimapi.Models
{
    public class userdetails
    {
        [Key]
        public int UserdetId { get; set; }

        [ForeignKey("UserCredentials")]
        public int Userid { get; set; }
        public virtual UserCredentials UserCredentials { get; set; }
        public string batch { get; set; }
        public string gender { get; set; }
        public long phoneno { get; set; }
        public DateTime dob { get; set; }
        public string sonof { get; set; }
        public long fatherphoneno { get; set; }

        public float Height { get; set; }
        public float Weight { get; set; }

    }
}
