﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace nikiswimapi.Models
{
    public class maindetails
    {
        [Key]
        public int mainid { get; set; }
        public string username { get; set; }
        public string email { get; set; }
        public long phonenum { get; set; }
        public string fathername { get; set; }
        public long fathernum { get; set; }
        public float ht { get; set; }
        public float wt { get; set; }
        public DateTime dob { get; set; }
        public string gender { get; set; }
        public string batch { get; set; }

    }
}
